#!/bin/bash

sudo docker stop user slave1 slave2 slaver my_server

